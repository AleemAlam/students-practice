function explore(){
    return ` <div id="left-margin">
    <h2>Earn a Degree</h2>
    <p>Breakthrough pricing on 100% online degrees designed to fit into your life.</p>

    <div class="grid">
        <div id="datasci">
            <h2>Data Science</h2>
            <hr />
            <div class="flex">
                <div>
                    <img
                        src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://coursera-university-assets.s3.amazonaws.com/70/de505d47be7d3a063b51b6f856a6e2/New-Block-M-Stacked-Blue-295C_600x600.png?auto=format%2Ccompress&dpr=2&w=36&h=36" />
                </div>
                <div>
                    <p>University of Michigan</p>
                    <h3>Master of Applied Data Science</h3>
                </div>
            </div>

            <div class="flex">
                <div>
                    <img
                        src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://coursera-university-assets.s3.amazonaws.com/bb/16e85962a963ab3546196705d25865/CUBoulder_360x360.png?auto=format%2Ccompress&dpr=2&w=36&h=36" />
                </div>
                <div>
                    <p>University of Colorado Boulder</p>
                    <h3>Master of Science & Data Science</h3>
                </div>
            </div>

            <div class="flex">
                <div>
                    <img
                        src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/http://coursera-university-assets.s3.amazonaws.com/d8/42cdc0ab2011e8b910bdf80bed9f6c/CenterILblock-ISQUAREOrangeBackgrnd.png?auto=format%2Ccompress&dpr=2&w=36&h=36" />
                </div>
                <div>
                    <p>University of Illinios at Urbana-Champaign</p>
                    <h3>Master in Computer Science</h3>
                </div>
            </div>

            <div class="flex">
                <div>
                    <img
                        src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/http://coursera-university-assets.s3.amazonaws.com/b1/90986f87ac4cbab18d95de27255442/HSE_white.png?auto=format%2Ccompress&dpr=2&w=36&h=36" />
                </div>
                <div>
                    <p>HSE University </p>
                    <h3>Master of Applied Data Science</h3>
                </div>
            </div>

            <div class="flex">
                <div>
                    <img
                        src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://coursera-university-assets.s3.amazonaws.com/70/de505d47be7d3a063b51b6f856a6e2/New-Block-M-Stacked-Blue-295C_600x600.png?auto=format%2Ccompress&dpr=2&w=36&h=36" />
                </div>
                <div>
                    <p>University of Michigan</p>
                    <h3>Master of Data Science</h3>
                </div>
            </div>

            <div class="flex">
                <div>
                    <img
                        src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://coursera-university-assets.s3.amazonaws.com/f2/1e0fc0666311e5bb98e7bc1b66e0e4/uniandessquare.png?auto=format%2Ccompress&dpr=2&w=36&h=36" />
                </div>
                <div>
                    <p>Universidad de Los Andes</p>
                    <h3>Maestria en inteligencia Analitica de Datos</h3>
                </div>
            </div>

        </div>

        <div id="datasci">
            <h2>Business</h2>
            <hr />
            <div class="flex">
                <div>
                    <img
                        src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://coursera-university-assets.s3.amazonaws.com/70/de505d47be7d3a063b51b6f856a6e2/New-Block-M-Stacked-Blue-295C_600x600.png?auto=format%2Ccompress&dpr=2&w=36&h=36" />
                </div>
                <div>
                    <p>University of Illinios at Urbana-Champaign</p>
                    <h3>Master of Business Administration(iMBA)</h3>
                </div>
            </div>

            <div class="flex">
                <div>
                    <img
                        src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://coursera-university-assets.s3.amazonaws.com/bb/16e85962a963ab3546196705d25865/CUBoulder_360x360.png?auto=format%2Ccompress&dpr=2&w=36&h=36" />
                </div>
                <div>
                    <p>University of London</p>
                    <h3>Bachelor of Science in Marketing</h3>
                </div>
            </div>

            <div class="flex">
                <div>
                    <img
                        src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/http://coursera-university-assets.s3.amazonaws.com/d8/42cdc0ab2011e8b910bdf80bed9f6c/CenterILblock-ISQUAREOrangeBackgrnd.png?auto=format%2Ccompress&dpr=2&w=36&h=36" />
                </div>
                <div>
                    <p>University of Illinios at Urbana-Champaign</p>
                    <h3>Master of Science in Management</h3>
                </div>
            </div>

            <div class="flex">
                <div>
                    <img
                        src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/http://coursera-university-assets.s3.amazonaws.com/b1/90986f87ac4cbab18d95de27255442/HSE_white.png?auto=format%2Ccompress&dpr=2&w=36&h=36" />
                </div>
                <div>
                    <p>University of North Texas</p>
                    <h3>Bachelor of Applied Arts & Sciences</h3>
                </div>
            </div>

            <div class="flex">
                <div>
                    <img
                        src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://coursera-university-assets.s3.amazonaws.com/70/de505d47be7d3a063b51b6f856a6e2/New-Block-M-Stacked-Blue-295C_600x600.png?auto=format%2Ccompress&dpr=2&w=36&h=36" />
                </div>
                <div>
                    <p>Fundacao instituto de Administracao</p>
                    <h3>Master of Business Administration</h3>
                </div>
            </div>

            <div class="flex">
                <div>
                    <img
                        src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://coursera-university-assets.s3.amazonaws.com/f2/1e0fc0666311e5bb98e7bc1b66e0e4/uniandessquare.png?auto=format%2Ccompress&dpr=2&w=36&h=36" />
                </div>
                <div>
                    <p>O.P. Jindal Global University</p>
                    <h3>MBA in Business Analytics</h3>
                </div>
            </div>

        </div>
    </div>
</div>`
}

export default explore;